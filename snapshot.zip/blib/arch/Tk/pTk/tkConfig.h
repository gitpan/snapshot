#ifndef _TKCONFIG
#define _TKCONFIG
#define ANSI_SIGNED_CHAR 1
#define HAS_STDARG 1
#define HAVE_LIMITS_H 1
#define HAVE_SYS_SELECT_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_UNISTD_H 1
#define SELECT_MASK fd_set
#define TIMEOFDAY_TZ 1
#define USE_PROTOTYPE 1
#endif
